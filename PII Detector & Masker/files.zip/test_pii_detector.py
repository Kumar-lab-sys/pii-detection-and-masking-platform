"""
tests/test_pii_detector.py
--------------------------
Pytest test suite for PII Detector & Masker.
Covers: regex detection, masking, CSV/JSON processing,
        edge cases, and the happy path end-to-end.
"""

import csv
import json
import os
import sys
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock

# Ensure src is importable
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.pii_detector import (
    RegexDetector,
    HybridPIIDetector,
    PIIType,
    PIIMatch,
    mask_value,
    _mask_email,
    _mask_phone,
    _mask_pan,
    _mask_aadhaar,
)
from src.pii_masker import process_csv, process_json, _apply_matches_to_text


# ═══════════════════════════════════════════════════════
# FIXTURES
# ═══════════════════════════════════════════════════════

@pytest.fixture
def regex_detector():
    return RegexDetector()


@pytest.fixture
def hybrid_detector_no_llm():
    return HybridPIIDetector(use_llm=False)


@pytest.fixture
def sample_csv(tmp_path):
    csv_file = tmp_path / "test_employees.csv"
    rows = [
        {"id": "1", "name": "Rahul Sharma", "email": "rahul@example.com",
         "phone": "9876543210", "pan": "ABCPS1234D", "aadhaar": "1234 5678 9012"},
        {"id": "2", "name": "Priya Patel", "email": "priya@corp.in",
         "phone": "+91-9845012345", "pan": "BCDQT5678E", "aadhaar": "987654321098"},
    ]
    with open(csv_file, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)
    return str(csv_file)


@pytest.fixture
def sample_json(tmp_path):
    json_file = tmp_path / "test_customers.json"
    data = {
        "customers": [
            {
                "id": "C001",
                "name": "Arjun Mehta",
                "email": "arjun@example.com",
                "phone": "9988776655",
                "pan": "ABCDE1234F",
                "aadhaar": "1234 5678 9012",
                "notes": "Contact via arjun.personal@gmail.com or call 9900112233",
            }
        ]
    }
    json_file.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return str(json_file)


# ═══════════════════════════════════════════════════════
# MASKING UNIT TESTS
# ═══════════════════════════════════════════════════════

class TestMasking:

    def test_mask_email_standard(self):
        masked = _mask_email("john.doe@example.com")
        assert masked.endswith("@example.com")
        assert masked.startswith("j")
        assert "***" in masked

    def test_mask_email_short_local(self):
        masked = _mask_email("a@b.com")
        assert "@b.com" in masked

    def test_mask_email_preserves_domain(self):
        masked = _mask_email("user@subdomain.company.co.in")
        assert "@subdomain.company.co.in" in masked

    def test_mask_phone_keeps_last_4(self):
        masked = _mask_phone("9876543210")
        assert masked.endswith("3210")
        assert "*" in masked

    def test_mask_phone_with_prefix(self):
        masked = _mask_phone("+91-9876543210")
        assert masked.endswith("3210")

    def test_mask_pan_format(self):
        masked = _mask_pan("ABCDE1234F")
        assert masked.startswith("ABC")
        assert masked.endswith("F")
        assert "#" in masked or "X" in masked

    def test_mask_aadhaar_keeps_last_4(self):
        masked = _mask_aadhaar("1234 5678 9012")
        assert masked.endswith("9012")
        assert "X" in masked

    def test_mask_aadhaar_no_spaces(self):
        masked = _mask_aadhaar("123456789012")
        assert masked.endswith("9012")

    def test_mask_value_dispatch(self):
        assert mask_value(PIIType.EMAIL, "x@y.com").endswith("@y.com")
        assert mask_value(PIIType.PHONE, "9876543210").endswith("3210")
        assert mask_value(PIIType.UNKNOWN, "something") == "***REDACTED***"


# ═══════════════════════════════════════════════════════
# REGEX DETECTOR TESTS
# ═══════════════════════════════════════════════════════

class TestRegexDetector:

    # ── Email ──────────────────────────────────────────
    def test_detects_standard_email(self, regex_detector):
        matches = regex_detector.scan_value("Contact me at john@example.com", "email")
        emails = [m for m in matches if m.pii_type == PIIType.EMAIL]
        assert len(emails) == 1
        assert emails[0].original_value == "john@example.com"

    def test_detects_indian_email_domain(self, regex_detector):
        matches = regex_detector.scan_value("priya@techcorp.in", "email")
        assert any(m.pii_type == PIIType.EMAIL for m in matches)

    def test_detects_multiple_emails(self, regex_detector):
        text = "Send to a@b.com and c@d.org"
        matches = regex_detector.scan_value(text)
        emails = [m for m in matches if m.pii_type == PIIType.EMAIL]
        assert len(emails) == 2

    # ── Phone ──────────────────────────────────────────
    def test_detects_10_digit_mobile(self, regex_detector):
        matches = regex_detector.scan_value("9876543210", "phone")
        phones = [m for m in matches if m.pii_type == PIIType.PHONE]
        assert len(phones) >= 1

    def test_detects_plus91_mobile(self, regex_detector):
        matches = regex_detector.scan_value("+91-9876543210", "phone")
        phones = [m for m in matches if m.pii_type == PIIType.PHONE]
        assert len(phones) >= 1

    def test_detects_landline(self, regex_detector):
        matches = regex_detector.scan_value("040-23456789")
        phones = [m for m in matches if m.pii_type == PIIType.PHONE]
        assert len(phones) >= 1

    def test_rejects_short_number(self, regex_detector):
        matches = regex_detector.scan_value("12345")
        phones = [m for m in matches if m.pii_type == PIIType.PHONE]
        assert len(phones) == 0

    # ── PAN ────────────────────────────────────────────
    def test_detects_pan(self, regex_detector):
        matches = regex_detector.scan_value("PAN: ABCDE1234F")
        pans = [m for m in matches if m.pii_type == PIIType.PAN]
        assert len(pans) == 1
        assert pans[0].original_value == "ABCDE1234F"

    def test_rejects_invalid_pan(self, regex_detector):
        matches = regex_detector.scan_value("ABC123")
        pans = [m for m in matches if m.pii_type == PIIType.PAN]
        assert len(pans) == 0

    def test_pan_case_sensitive(self, regex_detector):
        # PAN must be uppercase
        matches = regex_detector.scan_value("abcde1234f")
        pans = [m for m in matches if m.pii_type == PIIType.PAN]
        assert len(pans) == 0

    # ── Aadhaar ────────────────────────────────────────
    def test_detects_aadhaar_with_spaces(self, regex_detector):
        matches = regex_detector.scan_value("UID: 1234 5678 9012")
        aadhaar = [m for m in matches if m.pii_type == PIIType.AADHAAR]
        assert len(aadhaar) >= 1

    def test_detects_aadhaar_no_spaces(self, regex_detector):
        matches = regex_detector.scan_value("234567890123")
        aadhaar = [m for m in matches if m.pii_type == PIIType.AADHAAR]
        assert len(aadhaar) >= 1

    def test_source_is_regex(self, regex_detector):
        matches = regex_detector.scan_value("test@example.com")
        assert all(m.source == "regex" for m in matches)

    # ── Dict scanning ──────────────────────────────────
    def test_scan_dict(self, regex_detector):
        record = {
            "email": "user@example.com",
            "phone": "9876543210",
            "name": "No PII Here",
        }
        matches = regex_detector.scan_dict(record)
        types = {m.pii_type for m in matches}
        assert PIIType.EMAIL in types
        assert PIIType.PHONE in types

    def test_nested_dict(self, regex_detector):
        record = {"contact": {"email": "a@b.com", "phone": "9876543210"}}
        matches = regex_detector.scan_dict(record)
        assert len(matches) >= 2

    # ── No false positives on clean data ──────────────
    def test_no_false_positive_clean_text(self, regex_detector):
        matches = regex_detector.scan_value("Hello World")
        assert len(matches) == 0

    def test_no_false_positive_number(self, regex_detector):
        matches = regex_detector.scan_value("Total: 12345")
        pans = [m for m in matches if m.pii_type == PIIType.PAN]
        assert len(pans) == 0


# ═══════════════════════════════════════════════════════
# HYBRID DETECTOR (no LLM)
# ═══════════════════════════════════════════════════════

class TestHybridDetector:

    def test_hybrid_no_llm_matches_regex(self, hybrid_detector_no_llm):
        matches = hybrid_detector_no_llm.scan_value("rahul@example.com", "email")
        assert any(m.pii_type == PIIType.EMAIL for m in matches)

    def test_hybrid_scan_record(self, hybrid_detector_no_llm):
        record = {
            "email": "user@test.com",
            "phone": "9876543210",
            "pan": "ABCDE1234F",
            "aadhaar": "1234 5678 9012",
            "name": "Clean Name",
        }
        matches = hybrid_detector_no_llm.scan_record(record)
        types = {m.pii_type for m in matches}
        assert PIIType.EMAIL in types
        assert PIIType.PHONE in types
        assert PIIType.PAN in types
        assert PIIType.AADHAAR in types

    def test_hybrid_nested_json_record(self, hybrid_detector_no_llm):
        record = {
            "user": {
                "contact": {
                    "email": "nested@example.com"
                }
            }
        }
        matches = hybrid_detector_no_llm.scan_record(record)
        assert any(m.pii_type == PIIType.EMAIL for m in matches)


# ═══════════════════════════════════════════════════════
# APPLY MATCHES TO TEXT
# ═══════════════════════════════════════════════════════

class TestApplyMatches:

    def test_replaces_single_pii(self):
        text = "Email me at john@example.com please"
        matches = [PIIMatch(PIIType.EMAIL, "john@example.com", "j***@example.com", "regex")]
        result = _apply_matches_to_text(text, matches)
        assert "john@example.com" not in result
        assert "j***@example.com" in result

    def test_replaces_multiple_pii(self):
        text = "PAN ABCDE1234F, phone 9876543210"
        matches = [
            PIIMatch(PIIType.PAN, "ABCDE1234F", "ABCXX####F", "regex"),
            PIIMatch(PIIType.PHONE, "9876543210", "******3210", "regex"),
        ]
        result = _apply_matches_to_text(text, matches)
        assert "ABCDE1234F" not in result
        assert "9876543210" not in result

    def test_no_matches_returns_original(self):
        text = "No PII here"
        result = _apply_matches_to_text(text, [])
        assert result == text


# ═══════════════════════════════════════════════════════
# CSV PROCESSING — HAPPY PATH
# ═══════════════════════════════════════════════════════

class TestCSVProcessing:

    def test_happy_path_csv(self, sample_csv, tmp_path):
        out_csv = str(tmp_path / "masked.csv")
        out_report = str(tmp_path / "report.json")

        report = process_csv(sample_csv, out_csv, out_report, use_llm=False)

        # Report basics
        assert report.total_records == 2
        assert report.total_pii_found > 0

        # Output file exists
        assert Path(out_csv).exists()
        assert Path(out_report).exists()

    def test_csv_masked_file_has_no_original_pii(self, sample_csv, tmp_path):
        out_csv = str(tmp_path / "masked.csv")
        out_report = str(tmp_path / "report.json")
        process_csv(sample_csv, out_csv, out_report, use_llm=False)

        with open(out_csv, newline="", encoding="utf-8") as f:
            content = f.read()

        # Original PII should not appear
        assert "rahul@example.com" not in content
        assert "priya@corp.in" not in content
        assert "ABCPS1234D" not in content
        assert "BCDQT5678E" not in content

    def test_csv_masked_file_preserves_structure(self, sample_csv, tmp_path):
        out_csv = str(tmp_path / "masked.csv")
        out_report = str(tmp_path / "report.json")
        process_csv(sample_csv, out_csv, out_report, use_llm=False)

        with open(out_csv, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            rows = list(reader)

        assert len(rows) == 2
        assert "id" in rows[0]
        assert "name" in rows[0]

    def test_csv_report_contains_findings(self, sample_csv, tmp_path):
        out_csv = str(tmp_path / "masked.csv")
        out_report = str(tmp_path / "report.json")
        report = process_csv(sample_csv, out_csv, out_report, use_llm=False)

        assert len(report.findings) > 0
        for finding in report.findings:
            assert "pii_type" in finding
            assert "original" in finding
            assert "masked" in finding

    def test_csv_report_json_is_valid(self, sample_csv, tmp_path):
        out_csv = str(tmp_path / "masked.csv")
        out_report = str(tmp_path / "report.json")
        process_csv(sample_csv, out_csv, out_report, use_llm=False)

        with open(out_report, encoding="utf-8") as f:
            data = json.load(f)

        assert "total_pii_found" in data
        assert "findings_by_type" in data
        assert "column_summary" in data
        assert "findings" in data

    def test_csv_detects_all_pii_types(self, sample_csv, tmp_path):
        out_csv = str(tmp_path / "masked.csv")
        out_report = str(tmp_path / "report.json")
        report = process_csv(sample_csv, out_csv, out_report, use_llm=False)

        types_found = set(report.findings_by_type.keys())
        assert "EMAIL" in types_found
        assert "PHONE" in types_found
        assert "PAN" in types_found
        assert "AADHAAR" in types_found


# ═══════════════════════════════════════════════════════
# JSON PROCESSING — HAPPY PATH
# ═══════════════════════════════════════════════════════

class TestJSONProcessing:

    def test_happy_path_json(self, sample_json, tmp_path):
        out_json = str(tmp_path / "masked.json")
        out_report = str(tmp_path / "report.json")

        report = process_json(sample_json, out_json, out_report, use_llm=False)

        assert report.total_pii_found > 0
        assert Path(out_json).exists()
        assert Path(out_report).exists()

    def test_json_masked_removes_original_pii(self, sample_json, tmp_path):
        out_json = str(tmp_path / "masked.json")
        out_report = str(tmp_path / "report.json")
        process_json(sample_json, out_json, out_report, use_llm=False)

        with open(out_json, encoding="utf-8") as f:
            content = f.read()

        assert "arjun@example.com" not in content
        assert "ABCDE1234F" not in content
        assert "9988776655" not in content

    def test_json_output_is_valid_json(self, sample_json, tmp_path):
        out_json = str(tmp_path / "masked.json")
        out_report = str(tmp_path / "report.json")
        process_json(sample_json, out_json, out_report, use_llm=False)

        with open(out_json, encoding="utf-8") as f:
            data = json.load(f)

        assert "customers" in data
        assert len(data["customers"]) == 1

    def test_json_preserves_non_pii_fields(self, sample_json, tmp_path):
        out_json = str(tmp_path / "masked.json")
        out_report = str(tmp_path / "report.json")
        process_json(sample_json, out_json, out_report, use_llm=False)

        with open(out_json, encoding="utf-8") as f:
            data = json.load(f)

        customer = data["customers"][0]
        assert customer["id"] == "C001"
        assert customer["name"] == "Arjun Mehta"

    def test_json_detects_pii_in_free_text_notes(self, sample_json, tmp_path):
        out_json = str(tmp_path / "masked.json")
        out_report = str(tmp_path / "report.json")
        report = process_json(sample_json, out_json, out_report, use_llm=False)

        # notes field contains email + phone — regex should catch them
        note_findings = [f for f in report.findings if "notes" in f.get("column", "")]
        assert len(note_findings) >= 1


# ═══════════════════════════════════════════════════════
# EDGE CASES
# ═══════════════════════════════════════════════════════

class TestEdgeCases:

    def test_empty_string(self, regex_detector):
        matches = regex_detector.scan_value("")
        assert matches == []

    def test_none_value_as_string(self, regex_detector):
        matches = regex_detector.scan_value("None")
        assert matches == []

    def test_pii_in_long_sentence(self, regex_detector):
        text = ("Please update the records for our employee whose PAN is ABCDE1234F "
                "and Aadhaar 1234 5678 9012. Reach them at user@company.com.")
        matches = regex_detector.scan_value(text)
        types = {m.pii_type for m in matches}
        assert PIIType.PAN in types
        assert PIIType.AADHAAR in types
        assert PIIType.EMAIL in types

    def test_multiple_pii_same_type(self, regex_detector):
        text = "Emails: a@x.com and b@y.org"
        matches = regex_detector.scan_value(text)
        emails = [m for m in matches if m.pii_type == PIIType.EMAIL]
        assert len(emails) == 2

    def test_csv_empty_column(self, tmp_path):
        csv_file = tmp_path / "empty_col.csv"
        rows = [{"id": "1", "email": "", "phone": "9876543210"}]
        with open(csv_file, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["id", "email", "phone"])
            writer.writeheader()
            writer.writerows(rows)

        out_csv = str(tmp_path / "masked.csv")
        out_report = str(tmp_path / "report.json")
        report = process_csv(str(csv_file), out_csv, out_report, use_llm=False)
        assert report.total_records == 1

    def test_json_list_of_records(self, tmp_path):
        json_file = tmp_path / "list.json"
        data = [
            {"email": "a@b.com", "phone": "9876543210"},
            {"email": "c@d.com", "phone": "8765432109"},
        ]
        json_file.write_text(json.dumps(data), encoding="utf-8")

        out_json = str(tmp_path / "masked.json")
        out_report = str(tmp_path / "report.json")
        report = process_json(str(json_file), out_json, out_report, use_llm=False)
        assert report.total_pii_found >= 4  # 2 emails + 2 phones


# ═══════════════════════════════════════════════════════
# REPORT STRUCTURE TESTS
# ═══════════════════════════════════════════════════════

class TestReportStructure:

    def test_report_has_required_keys(self, sample_csv, tmp_path):
        out = str(tmp_path / "masked.csv")
        rpt = str(tmp_path / "report.json")
        process_csv(sample_csv, out, rpt, use_llm=False)

        with open(rpt, encoding="utf-8") as f:
            data = json.load(f)

        required = ["scanned_file", "scan_timestamp", "total_records",
                    "total_pii_found", "findings_by_type", "column_summary", "findings"]
        for key in required:
            assert key in data, f"Missing key: {key}"

    def test_findings_have_source_field(self, sample_csv, tmp_path):
        out = str(tmp_path / "masked.csv")
        rpt = str(tmp_path / "report.json")
        report = process_csv(sample_csv, out, rpt, use_llm=False)

        for finding in report.findings:
            assert finding["source"] in ("regex", "llm")

    def test_findings_count_matches_total(self, sample_csv, tmp_path):
        out = str(tmp_path / "masked.csv")
        rpt = str(tmp_path / "report.json")
        report = process_csv(sample_csv, out, rpt, use_llm=False)

        assert len(report.findings) == report.total_pii_found
