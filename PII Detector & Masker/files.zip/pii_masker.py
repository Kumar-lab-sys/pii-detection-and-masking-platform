"""
pii_masker.py
-------------
Applies PII masks to CSV and JSON files using HybridPIIDetector.
Produces:
  - A masked copy of the file
  - A JSON report of all findings
"""

import csv
import json
import re
import copy
from pathlib import Path
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Any

from src.pii_detector import HybridPIIDetector, PIIMatch, PIIType


# ─────────────────────────────────────────────
# Report structure
# ─────────────────────────────────────────────
@dataclass
class PIIReport:
    scanned_file: str
    scan_timestamp: str
    total_records: int
    total_pii_found: int
    findings_by_type: dict = field(default_factory=dict)
    findings: list[dict] = field(default_factory=list)
    column_summary: dict = field(default_factory=dict)


# ─────────────────────────────────────────────
# Apply masks to a string value
# ─────────────────────────────────────────────
def _apply_matches_to_text(text: str, matches: list[PIIMatch]) -> str:
    """Replace all matched PII in a string with their masked equivalents."""
    result = text
    # Sort by length desc to avoid partial replacements
    sorted_matches = sorted(matches, key=lambda m: len(m.original_value), reverse=True)
    for match in sorted_matches:
        result = result.replace(match.original_value, match.masked_value)
    return result


# ─────────────────────────────────────────────
# CSV Processing
# ─────────────────────────────────────────────
def process_csv(
    input_path: str,
    output_path: str,
    report_path: str,
    use_llm: bool = True,
    api_key: str | None = None,
) -> PIIReport:
    detector = HybridPIIDetector(use_llm=use_llm, api_key=api_key)
    input_path = Path(input_path)
    output_path = Path(output_path)
    report_path = Path(report_path)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.parent.mkdir(parents=True, exist_ok=True)

    all_findings: list[PIIMatch] = []
    masked_rows: list[dict] = []

    with open(input_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames or []
        rows = list(reader)

    for row in rows:
        masked_row = {}
        for col, val in row.items():
            if val is None:
                masked_row[col] = val
                continue
            matches = detector.scan_value(str(val), column=col)
            all_findings.extend(matches)
            masked_row[col] = _apply_matches_to_text(str(val), matches) if matches else val
        masked_rows.append(masked_row)

    # Write masked CSV
    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(masked_rows)

    report = _build_report(str(input_path), len(rows), all_findings)
    _write_report(report, report_path)
    return report


# ─────────────────────────────────────────────
# JSON Processing
# ─────────────────────────────────────────────
def _mask_json_node(node: Any, detector: HybridPIIDetector,
                     findings: list, path: str = "") -> Any:
    if isinstance(node, dict):
        return {k: _mask_json_node(v, detector, findings, f"{path}.{k}" if path else k)
                for k, v in node.items()}
    elif isinstance(node, list):
        return [_mask_json_node(item, detector, findings, f"{path}[{i}]")
                for i, item in enumerate(node)]
    elif isinstance(node, str):
        col = path.split(".")[-1].split("[")[0]
        matches = detector.scan_value(node, column=col)
        findings.extend(matches)
        return _apply_matches_to_text(node, matches) if matches else node
    else:
        return node


def process_json(
    input_path: str,
    output_path: str,
    report_path: str,
    use_llm: bool = True,
    api_key: str | None = None,
) -> PIIReport:
    detector = HybridPIIDetector(use_llm=use_llm, api_key=api_key)
    input_path = Path(input_path)
    output_path = Path(output_path)
    report_path = Path(report_path)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.parent.mkdir(parents=True, exist_ok=True)

    with open(input_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    all_findings: list[PIIMatch] = []
    masked_data = _mask_json_node(copy.deepcopy(data), detector, all_findings)

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(masked_data, f, indent=2, ensure_ascii=False)

    # Count top-level records
    record_count = len(data) if isinstance(data, list) else 1
    if isinstance(data, dict):
        # Try to find the main array
        for v in data.values():
            if isinstance(v, list):
                record_count = len(v)
                break

    report = _build_report(str(input_path), record_count, all_findings)
    _write_report(report, report_path)
    return report


# ─────────────────────────────────────────────
# Report builder
# ─────────────────────────────────────────────
def _build_report(file_path: str, record_count: int, findings: list[PIIMatch]) -> PIIReport:
    by_type: dict[str, int] = {}
    by_col: dict[str, list[str]] = {}

    for f in findings:
        by_type[f.pii_type.value] = by_type.get(f.pii_type.value, 0) + 1
        col = f.column or "unknown"
        by_col.setdefault(col, [])
        if f.pii_type.value not in by_col[col]:
            by_col[col].append(f.pii_type.value)

    return PIIReport(
        scanned_file=file_path,
        scan_timestamp=datetime.utcnow().isoformat() + "Z",
        total_records=record_count,
        total_pii_found=len(findings),
        findings_by_type=by_type,
        column_summary=by_col,
        findings=[
            {
                "column": m.column,
                "pii_type": m.pii_type.value,
                "original": m.original_value,
                "masked": m.masked_value,
                "source": m.source,
                "confidence": m.confidence,
            }
            for m in findings
        ],
    )


def _write_report(report: PIIReport, path: Path):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(asdict(report), f, indent=2, ensure_ascii=False)
