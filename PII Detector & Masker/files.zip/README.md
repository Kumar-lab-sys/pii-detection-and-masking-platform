# PII Detector & Masker — AI Agent POC

> **Business Problem:** Datasets (CSV / JSON) accidentally contain Personally Identifiable Information (PII). This tool auto-detects and masks PII before data is shared, exported, or stored — without requiring manual review.

---

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                      agent.py  (CLI)                    │
│  reads CSV / JSON  →  HybridPIIDetector  →  masked copy │
│                                  ↓                      │
│                          PIIReport (JSON)                │
└─────────────────────────────────────────────────────────┘

HybridPIIDetector
  ├── RegexDetector   ← fast, deterministic, runs on every column
  └── LLMDetector     ← Claude API, runs on free-text / notes columns
```

## PII Types Detected

| Type    | Pattern examples                          | Masking example                  |
|---------|-------------------------------------------|----------------------------------|
| EMAIL   | user@example.com, priya@corp.in           | u***@example.com                 |
| PHONE   | 9876543210, +91-9845012345, 040-23456789  | ******3210                       |
| PAN     | ABCDE1234F                                | ABCXX####F                       |
| AADHAAR | 1234 5678 9012, 987654321098              | XXXX XXXX 9012                   |
| UNKNOWN | Anything the LLM flags but can't classify | ***REDACTED***                  |

---

## Quick Start

```bash
# Regex-only (no API key needed)
python agent.py --input data/sample_employees.csv --no-llm

# Hybrid mode (Regex + Claude LLM)
export ANTHROPIC_API_KEY=sk-ant-...
python agent.py --input data/sample_customers.json

# Custom output paths
python agent.py --input mydata.csv --output out/safe.csv --report out/report.json
```

---

## Output

**Masked file** — identical structure, PII replaced:
```
Before:  rahul.sharma@example.com  →  After: r***@example.com
Before:  ABCPS1234D                →  After: ABCXX####D
Before:  9876543210                →  After: ******3210
Before:  1234 5678 9012            →  After: XXXX XXXX 9012
```

**Report JSON** (`*_pii_report.json`):
```json
{
  "scanned_file": "data/sample_employees.csv",
  "scan_timestamp": "2025-06-01T10:30:00Z",
  "total_records": 8,
  "total_pii_found": 33,
  "findings_by_type": { "EMAIL": 8, "PHONE": 11, "PAN": 8, "AADHAAR": 6 },
  "column_summary": {
    "email":      ["EMAIL"],
    "phone":      ["PHONE"],
    "pan_number": ["PAN"],
    "aadhaar":    ["AADHAAR"]
  },
  "findings": [
    { "column": "email", "pii_type": "EMAIL",
      "original": "rahul@example.com", "masked": "r***@example.com",
      "source": "regex", "confidence": 1.0 }
  ]
}
```

---

## Project Structure

```
pii_detector/
├── agent.py                        ← CLI entry point
├── run_tests.py                    ← Self-contained test runner (no pytest needed)
├── src/
│   ├── pii_detector.py             ← RegexDetector, LLMDetector, HybridPIIDetector
│   └── pii_masker.py               ← process_csv(), process_json(), PIIReport
├── tests/
│   └── test_pii_detector.py        ← pytest-compatible test suite (46 tests)
├── data/
│   ├── sample_employees.csv        ← Sample CSV with PII
│   └── sample_customers.json       ← Sample JSON with PII
└── output/                         ← Masked files + reports (auto-created)
```

---

## Running Tests

```bash
# Self-contained runner (no dependencies):
python run_tests.py

# With pytest installed:
pytest tests/ -v
```

**Test coverage: 46 tests across 8 suites**
- Masking unit tests (email, phone, PAN, Aadhaar)
- Regex detector (email, phone, PAN, Aadhaar, false-positives)
- Hybrid detector (no-LLM mode, nested records)
- Apply matches to text
- CSV processing happy path (7 tests)
- JSON processing happy path (5 tests)
- Edge cases (empty strings, long sentences, list roots)
- Report structure validation

---

## How the Hybrid Detection Works

1. **Regex first** — every column value is scanned with compiled patterns. Fast, zero API calls, deterministic.
2. **LLM second** — Claude is invoked only for:
   - Free-text columns (`notes`, `comments`, `address`, `remarks`, etc.)
   - Columns whose name hints at PII but regex found nothing (`contact`, `uid`, `tax_id`, etc.)
3. **De-duplication** — LLM findings that duplicate regex hits are dropped.
4. **Source tagging** — every finding records `"source": "regex"` or `"source": "llm"` for auditability.

This keeps API costs low while catching contextual PII (e.g. *"please contact me at..."* embedded in a notes field).

---

## Extending

Add a new PII type (e.g. passport numbers):
```python
# In src/pii_detector.py
class PIIType(str, Enum):
    ...
    PASSPORT = "PASSPORT"

REGEX_PATTERNS[PIIType.PASSPORT] = [
    re.compile(r"[A-Z][1-9][0-9]{7}")
]

MASKERS[PIIType.PASSPORT] = lambda v: v[:1] + "*" * (len(v)-1)
```
