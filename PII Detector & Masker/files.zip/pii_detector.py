"""
pii_detector.py
---------------
Hybrid Regex + LLM PII Detector for Indian & Global PII types.
Detects: Email, Phone (Indian/International), PAN, Aadhaar, and
         contextual PII discovered by an LLM agent.
"""

import re
import json
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


# ─────────────────────────────────────────────
# PII Types
# ─────────────────────────────────────────────
class PIIType(str, Enum):
    EMAIL = "EMAIL"
    PHONE = "PHONE"
    PAN = "PAN"
    AADHAAR = "AADHAAR"
    UNKNOWN = "UNKNOWN"


# ─────────────────────────────────────────────
# Detection Result
# ─────────────────────────────────────────────
@dataclass
class PIIMatch:
    pii_type: PIIType
    original_value: str
    masked_value: str
    source: str          # "regex" | "llm"
    column: str = ""
    confidence: float = 1.0
    context: str = ""


# ─────────────────────────────────────────────
# Regex Patterns
# ─────────────────────────────────────────────
REGEX_PATTERNS: dict[PIIType, list[re.Pattern]] = {
    PIIType.EMAIL: [
        re.compile(r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}", re.IGNORECASE),
    ],
    PIIType.PHONE: [
        # Indian mobiles: +91-XXXXXXXXXX, 91XXXXXXXXXX, 0XXXXXXXXXX, plain 10-digit
        re.compile(r"(?:(?:\+|00)91[\s\-]?)?[6-9]\d{9}"),
        # Landline: 0XX-XXXXXXXX
        re.compile(r"0\d{2,4}[\s\-]\d{6,8}"),
        # International: 1-800-XXX-XXXX style
        re.compile(r"1[\s\-]\d{3}[\s\-]\d{3}[\s\-]\d{4}"),
    ],
    PIIType.PAN: [
        # PAN: 5 letters, 4 digits, 1 letter  (e.g. ABCDE1234F)
        re.compile(r"\b[A-Z]{5}[0-9]{4}[A-Z]\b"),
    ],
    PIIType.AADHAAR: [
        # Aadhaar: 12 digits, optionally space/hyphen separated in groups of 4
        re.compile(r"\b[2-9]\d{3}[\s\-]?\d{4}[\s\-]?\d{4}\b"),
        re.compile(r"\b[2-9]\d{11}\b"),
    ],
}


# ─────────────────────────────────────────────
# Masking helpers
# ─────────────────────────────────────────────
def _mask_email(value: str) -> str:
    """john.doe@example.com → j***@example.com"""
    at = value.find("@")
    if at <= 0:
        return "***@***.***"
    local = value[:at]
    domain = value[at:]
    return local[0] + "*" * (len(local) - 1) + domain


def _mask_phone(value: str) -> str:
    """Keep last 4 digits: +91-9876543210 → ******3210"""
    digits = re.sub(r"\D", "", value)
    return "*" * (len(digits) - 4) + digits[-4:]


def _mask_pan(value: str) -> str:
    """ABCDE1234F → ABCXX####F"""
    return value[:3] + "XX" + "####" + value[-1]


def _mask_aadhaar(value: str) -> str:
    """Keep last 4: 1234 5678 9012 → XXXX XXXX 9012"""
    digits = re.sub(r"\D", "", value)
    masked = "X" * (len(digits) - 4) + digits[-4:]
    # re-insert original spacing style
    if " " in value or "-" in value:
        sep = " " if " " in value else "-"
        return sep.join([masked[i:i+4] for i in range(0, len(masked), 4)])
    return masked


MASKERS = {
    PIIType.EMAIL: _mask_email,
    PIIType.PHONE: _mask_phone,
    PIIType.PAN: _mask_pan,
    PIIType.AADHAAR: _mask_aadhaar,
    PIIType.UNKNOWN: lambda v: "***REDACTED***",
}


def mask_value(pii_type: PIIType, value: str) -> str:
    return MASKERS.get(pii_type, MASKERS[PIIType.UNKNOWN])(value)


# ─────────────────────────────────────────────
# Regex Detector
# ─────────────────────────────────────────────
class RegexDetector:
    """Fast, deterministic first-pass PII scanner."""

    def scan_value(self, value: str, column: str = "") -> list[PIIMatch]:
        if not isinstance(value, str):
            value = str(value)
        matches: list[PIIMatch] = []
        seen: set[str] = set()

        for pii_type, patterns in REGEX_PATTERNS.items():
            for pat in patterns:
                for m in pat.finditer(value):
                    raw = m.group()
                    if raw in seen:
                        continue
                    seen.add(raw)
                    masked = mask_value(pii_type, raw)
                    matches.append(PIIMatch(
                        pii_type=pii_type,
                        original_value=raw,
                        masked_value=masked,
                        source="regex",
                        column=column,
                        confidence=1.0,
                        context=value[:60],
                    ))
        return matches

    def scan_dict(self, record: dict, prefix: str = "") -> list[PIIMatch]:
        all_matches: list[PIIMatch] = []
        for key, val in record.items():
            col = f"{prefix}.{key}" if prefix else key
            if isinstance(val, dict):
                all_matches.extend(self.scan_dict(val, prefix=col))
            elif isinstance(val, list):
                for i, item in enumerate(val):
                    if isinstance(item, dict):
                        all_matches.extend(self.scan_dict(item, prefix=f"{col}[{i}]"))
                    else:
                        all_matches.extend(self.scan_value(str(item), col))
            else:
                all_matches.extend(self.scan_value(str(val), col))
        return all_matches


# ─────────────────────────────────────────────
# LLM Detector (via Anthropic API)
# ─────────────────────────────────────────────
class LLMDetector:
    """
    Uses Claude to detect contextual or ambiguous PII that regex misses.
    Called only for free-text / notes columns, or when column name hints at PII.
    """

    LLM_SYSTEM = """You are a PII detection specialist. Analyse the given text and
identify any Personally Identifiable Information (PII). Focus on:
- Emails, phone numbers (Indian or international)
- Indian PAN numbers (format: AAAAA0000A)
- Indian Aadhaar numbers (12 digits, may be space-separated)
- Any other identifiers that could personally identify someone

Return ONLY a JSON array (no markdown, no explanation) of objects like:
[{"pii_type": "EMAIL|PHONE|PAN|AADHAAR|UNKNOWN", "value": "<exact substring>", "confidence": 0.0-1.0}]
If no PII found, return [].
"""

    def __init__(self, api_key: str | None = None):
        self._api_key = api_key  # injected; handled by proxy in Claude artifacts
        self._regex = RegexDetector()

    def scan_value(self, value: str, column: str = "") -> list[PIIMatch]:
        """Call LLM for contextual detection on free-text fields."""
        import urllib.request

        payload = {
            "model": "claude-sonnet-4-6",
            "max_tokens": 1000,
            "system": self.LLM_SYSTEM,
            "messages": [{"role": "user", "content": f"Column: {column}\nValue: {value}"}],
        }
        headers = {"Content-Type": "application/json"}
        if self._api_key:
            headers["x-api-key"] = self._api_key

        try:
            req = urllib.request.Request(
                "https://api.anthropic.com/v1/messages",
                data=json.dumps(payload).encode(),
                headers=headers,
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=15) as resp:
                body = json.loads(resp.read())
            raw_text = "".join(
                b.get("text", "") for b in body.get("content", []) if b.get("type") == "text"
            )
            items = json.loads(raw_text.strip())
        except Exception:
            return []

        matches: list[PIIMatch] = []
        for item in items:
            pii_type_str = item.get("pii_type", "UNKNOWN").upper()
            try:
                pii_type = PIIType(pii_type_str)
            except ValueError:
                pii_type = PIIType.UNKNOWN
            raw = item.get("value", "")
            if not raw:
                continue
            masked = mask_value(pii_type, raw)
            matches.append(PIIMatch(
                pii_type=pii_type,
                original_value=raw,
                masked_value=masked,
                source="llm",
                column=column,
                confidence=float(item.get("confidence", 0.8)),
                context=value[:60],
            ))
        return matches


# ─────────────────────────────────────────────
# Hybrid Detector (Regex first, LLM for gaps)
# ─────────────────────────────────────────────
FREE_TEXT_HINTS = {"note", "notes", "comment", "comments", "description",
                   "remarks", "address", "message", "text", "details"}


class HybridPIIDetector:
    """
    Orchestrates regex + LLM detection.
    - Regex runs on every column (fast, deterministic).
    - LLM runs on free-text columns or columns with PII-hinting names,
      and on any value where regex found nothing but the column name suggests PII.
    """

    def __init__(self, use_llm: bool = True, api_key: str | None = None):
        self.regex = RegexDetector()
        self.llm = LLMDetector(api_key=api_key) if use_llm else None
        self.use_llm = use_llm

    def _is_free_text_column(self, col: str) -> bool:
        col_lower = col.lower().split(".")[-1]  # handle nested keys
        return any(hint in col_lower for hint in FREE_TEXT_HINTS)

    def scan_value(self, value: str, column: str = "") -> list[PIIMatch]:
        regex_matches = self.regex.scan_value(value, column)
        if not self.use_llm or not self.llm:
            return regex_matches

        # Run LLM on free-text columns or if regex found nothing on a suspicious column
        pii_hints = {"email", "phone", "mobile", "pan", "aadhaar", "uid",
                     "tax", "contact", "id"}
        col_lower = column.lower()
        col_suspicious = any(h in col_lower for h in pii_hints)

        if self._is_free_text_column(column) or (col_suspicious and not regex_matches):
            llm_matches = self.llm.scan_value(value, column)
            # De-duplicate against regex findings
            regex_originals = {m.original_value for m in regex_matches}
            for lm in llm_matches:
                if lm.original_value not in regex_originals:
                    regex_matches.append(lm)

        return regex_matches

    def scan_record(self, record: dict) -> list[PIIMatch]:
        """Scan a flat or nested dict record."""
        all_matches: list[PIIMatch] = []

        def _recurse(obj: Any, prefix: str = ""):
            if isinstance(obj, dict):
                for k, v in obj.items():
                    path = f"{prefix}.{k}" if prefix else k
                    _recurse(v, path)
            elif isinstance(obj, list):
                for i, item in enumerate(obj):
                    _recurse(item, f"{prefix}[{i}]")
            else:
                all_matches.extend(self.scan_value(str(obj), prefix))

        _recurse(record)
        return all_matches
