"""
agent.py
--------
CLI Agent for PII Detection & Masking.

Usage:
    python agent.py --input data/sample_employees.csv
    python agent.py --input data/sample_customers.json --no-llm
    python agent.py --input data/sample_employees.csv --output out/masked.csv --report out/report.json
"""

import argparse
import sys
import os
from pathlib import Path

# Allow running from project root
sys.path.insert(0, str(Path(__file__).parent))

from src.pii_masker import process_csv, process_json


BANNER = """
╔═══════════════════════════════════════════════════════╗
║         PII Detector & Masker — AI Agent POC          ║
║   Hybrid Regex + LLM  |  CSV & JSON  |  India Ready   ║
╚═══════════════════════════════════════════════════════╝
"""


def main():
    print(BANNER)
    parser = argparse.ArgumentParser(description="PII Detector & Masker Agent")
    parser.add_argument("--input", required=True, help="Input CSV or JSON file path")
    parser.add_argument("--output", default=None, help="Output masked file path (optional)")
    parser.add_argument("--report", default=None, help="Output report JSON path (optional)")
    parser.add_argument("--no-llm", action="store_true", help="Disable LLM (regex-only mode)")
    parser.add_argument("--api-key", default=None, help="Anthropic API key (or set ANTHROPIC_API_KEY env var)")
    args = parser.parse_args()

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"❌  File not found: {input_path}")
        sys.exit(1)

    suffix = input_path.suffix.lower()
    if suffix not in {".csv", ".json"}:
        print(f"❌  Unsupported file type: {suffix}  (supported: .csv, .json)")
        sys.exit(1)

    # Defaults
    stem = input_path.stem
    out_dir = Path("output")
    out_dir.mkdir(exist_ok=True)
    output_path = args.output or str(out_dir / f"{stem}_masked{suffix}")
    report_path = args.report or str(out_dir / f"{stem}_pii_report.json")

    api_key = args.api_key or os.environ.get("ANTHROPIC_API_KEY")
    use_llm = not args.no_llm and bool(api_key)

    print(f"📂  Input  : {input_path}")
    print(f"📄  Output : {output_path}")
    print(f"📊  Report : {report_path}")
    print(f"🤖  Mode   : {'Hybrid (Regex + LLM)' if use_llm else 'Regex-only'}")
    print()

    print("🔍  Scanning for PII …")
    if suffix == ".csv":
        report = process_csv(str(input_path), output_path, report_path, use_llm, api_key)
    else:
        report = process_json(str(input_path), output_path, report_path, use_llm, api_key)

    print(f"\n✅  Scan complete!")
    print(f"   Records scanned : {report.total_records}")
    print(f"   PII instances   : {report.total_pii_found}")
    print(f"\n   Breakdown by type:")
    for ptype, count in report.findings_by_type.items():
        print(f"     {ptype:<12} : {count}")

    print(f"\n   Columns with PII:")
    for col, types in report.column_summary.items():
        print(f"     {col:<30} → {', '.join(types)}")

    print(f"\n💾  Masked file  → {output_path}")
    print(f"📋  Full report  → {report_path}")


if __name__ == "__main__":
    main()
