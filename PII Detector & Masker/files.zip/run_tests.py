"""
run_tests.py
------------
Self-contained test runner (no external dependencies).
Mimics pytest's output style. Run with: python run_tests.py
"""

import sys
import traceback
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

# ── Minimal test framework ─────────────────────────────────────
class _Suite:
    def __init__(self):
        self.passed = []
        self.failed = []
        self.errors = []

_suite = _Suite()


def _run_test(name, fn):
    try:
        fn()
        _suite.passed.append(name)
        print(f"  \033[32m✓\033[0m  {name}")
    except AssertionError as e:
        _suite.failed.append((name, str(e)))
        print(f"  \033[31m✗\033[0m  {name}")
        print(f"       AssertionError: {e}")
    except Exception as e:
        _suite.errors.append((name, traceback.format_exc()))
        print(f"  \033[33m!\033[0m  {name}  [ERROR]")
        print(f"       {type(e).__name__}: {e}")


def section(title):
    print(f"\n\033[1;34m{'─'*60}\033[0m")
    print(f"\033[1;34m  {title}\033[0m")
    print(f"\033[1;34m{'─'*60}\033[0m")


# ── Imports ────────────────────────────────────────────────────
from src.pii_detector import (
    RegexDetector, HybridPIIDetector, PIIType, PIIMatch,
    mask_value, _mask_email, _mask_phone, _mask_pan, _mask_aadhaar,
)
from src.pii_masker import process_csv, process_json, _apply_matches_to_text
import csv, json, tempfile, os
from dataclasses import asdict


# ── Helpers ────────────────────────────────────────────────────
def make_sample_csv(path):
    rows = [
        {"id":"1","name":"Rahul Sharma","email":"rahul@example.com",
         "phone":"9876543210","pan":"ABCPS1234D","aadhaar":"1234 5678 9012"},
        {"id":"2","name":"Priya Patel","email":"priya@corp.in",
         "phone":"+91-9845012345","pan":"BCDQT5678E","aadhaar":"987654321098"},
    ]
    with open(path,"w",newline="",encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)


def make_sample_json(path):
    data = {"customers":[{
        "id":"C001","name":"Arjun Mehta","email":"arjun@example.com",
        "phone":"9988776655","pan":"ABCDE1234F","aadhaar":"1234 5678 9012",
        "notes":"Contact via arjun.personal@gmail.com or call 9900112233"
    }]}
    Path(path).write_text(json.dumps(data, indent=2), encoding="utf-8")


rd = RegexDetector()
hd = HybridPIIDetector(use_llm=False)


# ══════════════════════════════════════════════════════════════
print("\n\033[1;37m╔══════════════════════════════════════════════════╗\033[0m")
print("\033[1;37m║     PII Detector & Masker — Test Suite           ║\033[0m")
print("\033[1;37m╚══════════════════════════════════════════════════╝\033[0m")
t0 = time.time()


# ── MASKING ────────────────────────────────────────────────────
section("Masking Unit Tests")


def _t_email():
    m = _mask_email("john.doe@example.com")
    assert m.endswith("@example.com"), f"got {m}"
    assert m.startswith("j"), f"got {m}"
    assert "***" in m or "*" in m, f"got {m}"
_run_test("mask_email: preserves domain, hides local", _t_email)

def _t_email_domain():
    m = _mask_email("user@subdomain.company.co.in")
    assert "@subdomain.company.co.in" in m
_run_test("mask_email: multi-level domain preserved", _t_email_domain)

def _t_phone():
    m = _mask_phone("9876543210")
    assert m.endswith("3210"), f"got {m}"
    assert "*" in m
_run_test("mask_phone: keeps last 4 digits", _t_phone)

def _t_phone_prefix():
    m = _mask_phone("+91-9876543210")
    assert m.endswith("3210"), f"got {m}"
_run_test("mask_phone: handles +91 prefix", _t_phone_prefix)

def _t_pan():
    m = _mask_pan("ABCDE1234F")
    assert m.startswith("ABC"), f"got {m}"
    assert m.endswith("F"), f"got {m}"
    assert "ABCDE1234F" != m
_run_test("mask_pan: masks middle, keeps prefix and suffix", _t_pan)

def _t_aadhaar():
    m = _mask_aadhaar("1234 5678 9012")
    assert m.endswith("9012"), f"got {m}"
    assert "X" in m
_run_test("mask_aadhaar: keeps last 4, masks rest", _t_aadhaar)

def _t_aadhaar_ns():
    m = _mask_aadhaar("123456789012")
    assert m.endswith("9012"), f"got {m}"
_run_test("mask_aadhaar: no-space format", _t_aadhaar_ns)

def _t_mask_unknown():
    assert mask_value(PIIType.UNKNOWN, "something") == "***REDACTED***"
_run_test("mask_value: UNKNOWN type → REDACTED", _t_mask_unknown)


# ── REGEX EMAIL ────────────────────────────────────────────────
section("Regex Detector — Email")

def _t_re_email():
    m = rd.scan_value("Contact me at john@example.com", "email")
    em = [x for x in m if x.pii_type == PIIType.EMAIL]
    assert len(em) == 1
    assert em[0].original_value == "john@example.com"
_run_test("detects standard email in sentence", _t_re_email)

def _t_re_email_in():
    m = rd.scan_value("priya@techcorp.in", "email")
    assert any(x.pii_type == PIIType.EMAIL for x in m)
_run_test("detects .in domain email", _t_re_email_in)

def _t_re_multi_email():
    m = rd.scan_value("Send to a@b.com and c@d.org")
    em = [x for x in m if x.pii_type == PIIType.EMAIL]
    assert len(em) == 2, f"expected 2, got {len(em)}"
_run_test("detects multiple emails in one string", _t_re_multi_email)


# ── REGEX PHONE ────────────────────────────────────────────────
section("Regex Detector — Phone")

def _t_re_10d():
    m = rd.scan_value("9876543210", "phone")
    p = [x for x in m if x.pii_type == PIIType.PHONE]
    assert len(p) >= 1
_run_test("detects 10-digit Indian mobile", _t_re_10d)

def _t_re_plus91():
    m = rd.scan_value("+91-9876543210", "phone")
    p = [x for x in m if x.pii_type == PIIType.PHONE]
    assert len(p) >= 1
_run_test("detects +91 prefixed mobile", _t_re_plus91)

def _t_re_landline():
    m = rd.scan_value("040-23456789")
    p = [x for x in m if x.pii_type == PIIType.PHONE]
    assert len(p) >= 1
_run_test("detects landline format", _t_re_landline)

def _t_re_no_short():
    m = rd.scan_value("12345")
    p = [x for x in m if x.pii_type == PIIType.PHONE]
    assert len(p) == 0
_run_test("no false positive on short number", _t_re_no_short)


# ── REGEX PAN / AADHAAR ────────────────────────────────────────
section("Regex Detector — PAN & Aadhaar")

def _t_re_pan():
    m = rd.scan_value("PAN: ABCDE1234F")
    p = [x for x in m if x.pii_type == PIIType.PAN]
    assert len(p) == 1 and p[0].original_value == "ABCDE1234F"
_run_test("detects PAN in sentence", _t_re_pan)

def _t_re_pan_invalid():
    m = rd.scan_value("ABC123")
    p = [x for x in m if x.pii_type == PIIType.PAN]
    assert len(p) == 0
_run_test("rejects invalid PAN", _t_re_pan_invalid)

def _t_re_pan_case():
    m = rd.scan_value("abcde1234f")
    p = [x for x in m if x.pii_type == PIIType.PAN]
    assert len(p) == 0
_run_test("PAN is case-sensitive (lowercase not matched)", _t_re_pan_case)

def _t_re_aadhaar_spaced():
    m = rd.scan_value("UID: 2234 5678 9012")
    a = [x for x in m if x.pii_type == PIIType.AADHAAR]
    assert len(a) >= 1
_run_test("detects Aadhaar with spaces", _t_re_aadhaar_spaced)

def _t_re_aadhaar_plain():
    m = rd.scan_value("234567890123")
    a = [x for x in m if x.pii_type == PIIType.AADHAAR]
    assert len(a) >= 1
_run_test("detects Aadhaar without spaces", _t_re_aadhaar_plain)

def _t_re_source():
    m = rd.scan_value("test@example.com")
    assert all(x.source == "regex" for x in m)
_run_test("source field is 'regex'", _t_re_source)

def _t_re_no_fp():
    m = rd.scan_value("Hello World")
    assert len(m) == 0
_run_test("no false positives on clean text", _t_re_no_fp)


# ── HYBRID DETECTOR ────────────────────────────────────────────
section("Hybrid Detector (no LLM)")

def _t_hd_basic():
    m = hd.scan_value("rahul@example.com", "email")
    assert any(x.pii_type == PIIType.EMAIL for x in m)
_run_test("scan_value: detects email", _t_hd_basic)

def _t_hd_record():
    rec = {"email":"user@test.com","phone":"9876543210",
           "pan":"ABCDE1234F","aadhaar":"2234 5678 9012","name":"Clean"}
    m = hd.scan_record(rec)
    types = {x.pii_type for x in m}
    assert PIIType.EMAIL in types
    assert PIIType.PHONE in types
    assert PIIType.PAN in types
    assert PIIType.AADHAAR in types
_run_test("scan_record: detects all PII types", _t_hd_record)

def _t_hd_nested():
    rec = {"user": {"contact": {"email": "nested@example.com"}}}
    m = hd.scan_record(rec)
    assert any(x.pii_type == PIIType.EMAIL for x in m)
_run_test("scan_record: handles nested JSON", _t_hd_nested)


# ── APPLY MATCHES ──────────────────────────────────────────────
section("Apply Matches to Text")

def _t_am_single():
    text = "Email me at john@example.com please"
    matches = [PIIMatch(PIIType.EMAIL, "john@example.com", "j***@example.com", "regex")]
    result = _apply_matches_to_text(text, matches)
    assert "john@example.com" not in result
    assert "j***@example.com" in result
_run_test("replaces single PII match", _t_am_single)

def _t_am_multi():
    text = "PAN ABCDE1234F, phone 9876543210"
    matches = [
        PIIMatch(PIIType.PAN, "ABCDE1234F", "ABCXX####F", "regex"),
        PIIMatch(PIIType.PHONE, "9876543210", "******3210", "regex"),
    ]
    result = _apply_matches_to_text(text, matches)
    assert "ABCDE1234F" not in result
    assert "9876543210" not in result
_run_test("replaces multiple PII in same string", _t_am_multi)

def _t_am_none():
    text = "No PII here"
    assert _apply_matches_to_text(text, []) == text
_run_test("empty matches returns original text", _t_am_none)


# ── CSV PROCESSING ─────────────────────────────────────────────
section("CSV Processing — Happy Path")

with tempfile.TemporaryDirectory() as td:
    csv_in = os.path.join(td, "emp.csv")
    csv_out = os.path.join(td, "masked.csv")
    rpt_out = os.path.join(td, "report.json")
    make_sample_csv(csv_in)

    def _t_csv_basic():
        r = process_csv(csv_in, csv_out, rpt_out, use_llm=False)
        assert r.total_records == 2
        assert r.total_pii_found > 0
    _run_test("processes CSV: correct record count & finds PII", _t_csv_basic)

    def _t_csv_no_original():
        with open(csv_out, encoding="utf-8") as f:
            content = f.read()
        assert "rahul@example.com" not in content, "original email leaked"
        assert "priya@corp.in" not in content, "original email leaked"
        assert "ABCPS1234D" not in content, "original PAN leaked"
        assert "BCDQT5678E" not in content, "original PAN leaked"
    _run_test("masked CSV contains no original PII", _t_csv_no_original)

    def _t_csv_structure():
        with open(csv_out, newline="", encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
        assert len(rows) == 2
        assert "id" in rows[0]
    _run_test("masked CSV preserves row structure", _t_csv_structure)

    def _t_csv_report_keys():
        with open(rpt_out, encoding="utf-8") as f:
            d = json.load(f)
        for key in ["scanned_file","scan_timestamp","total_records",
                    "total_pii_found","findings_by_type","column_summary","findings"]:
            assert key in d, f"missing key: {key}"
    _run_test("report JSON has all required keys", _t_csv_report_keys)

    def _t_csv_all_types():
        with open(rpt_out, encoding="utf-8") as f:
            d = json.load(f)
        types = set(d["findings_by_type"].keys())
        assert "EMAIL" in types, f"types={types}"
        assert "PHONE" in types
        assert "PAN" in types
        assert "AADHAAR" in types
    _run_test("report captures all 4 PII types", _t_csv_all_types)

    def _t_csv_findings_source():
        with open(rpt_out, encoding="utf-8") as f:
            d = json.load(f)
        for f_item in d["findings"]:
            assert f_item["source"] in ("regex","llm"), f"bad source: {f_item['source']}"
    _run_test("each finding has valid source field", _t_csv_findings_source)

    def _t_csv_count_consistency():
        with open(rpt_out, encoding="utf-8") as f:
            d = json.load(f)
        assert len(d["findings"]) == d["total_pii_found"]
    _run_test("findings list length matches total_pii_found", _t_csv_count_consistency)


# ── JSON PROCESSING ────────────────────────────────────────────
section("JSON Processing — Happy Path")

with tempfile.TemporaryDirectory() as td:
    json_in = os.path.join(td, "cust.json")
    json_out = os.path.join(td, "masked.json")
    rpt_out = os.path.join(td, "report.json")
    make_sample_json(json_in)

    def _t_json_basic():
        r = process_json(json_in, json_out, rpt_out, use_llm=False)
        assert r.total_pii_found > 0
    _run_test("processes JSON: finds PII", _t_json_basic)

    def _t_json_no_original():
        with open(json_out, encoding="utf-8") as f:
            content = f.read()
        assert "arjun@example.com" not in content
        assert "ABCDE1234F" not in content
        assert "9988776655" not in content
    _run_test("masked JSON contains no original PII", _t_json_no_original)

    def _t_json_valid():
        with open(json_out, encoding="utf-8") as f:
            d = json.load(f)
        assert "customers" in d
    _run_test("output is valid JSON with original structure", _t_json_valid)

    def _t_json_non_pii_preserved():
        with open(json_out, encoding="utf-8") as f:
            d = json.load(f)
        c = d["customers"][0]
        assert c["id"] == "C001"
        assert c["name"] == "Arjun Mehta"
    _run_test("non-PII fields are preserved verbatim", _t_json_non_pii_preserved)

    def _t_json_notes():
        with open(rpt_out, encoding="utf-8") as f:
            d = json.load(f)
        note_findings = [f for f in d["findings"] if "notes" in f.get("column","")]
        assert len(note_findings) >= 1, "no findings in notes field"
    _run_test("PII in free-text notes column is detected", _t_json_notes)


# ── EDGE CASES ─────────────────────────────────────────────────
section("Edge Cases")

def _t_ec_empty():
    m = rd.scan_value("")
    assert m == []
_run_test("empty string returns no matches", _t_ec_empty)

def _t_ec_none_str():
    m = rd.scan_value("None")
    assert m == []
_run_test("string 'None' returns no matches", _t_ec_none_str)

def _t_ec_long_sentence():
    text = ("PAN is ABCDE1234F and Aadhaar 2234 5678 9012. "
            "Reach them at user@company.com.")
    m = rd.scan_value(text)
    types = {x.pii_type for x in m}
    assert PIIType.PAN in types
    assert PIIType.AADHAAR in types
    assert PIIType.EMAIL in types
_run_test("detects multiple PII types in long sentence", _t_ec_long_sentence)

def _t_ec_multi_same():
    m = rd.scan_value("Emails: a@x.com and b@y.org")
    em = [x for x in m if x.pii_type == PIIType.EMAIL]
    assert len(em) == 2
_run_test("detects multiple instances of same PII type", _t_ec_multi_same)

with tempfile.TemporaryDirectory() as td:
    def _t_ec_empty_col():
        cf = os.path.join(td, "ec.csv")
        rows = [{"id":"1","email":"","phone":"9876543210"}]
        with open(cf,"w",newline="",encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=["id","email","phone"])
            w.writeheader(); w.writerows(rows)
        r = process_csv(cf, os.path.join(td,"m.csv"), os.path.join(td,"r.json"), use_llm=False)
        assert r.total_records == 1
    _run_test("CSV with empty column processes without error", _t_ec_empty_col)

    def _t_ec_json_list():
        jf = os.path.join(td, "list.json")
        data = [{"email":"a@b.com","phone":"9876543210"},
                {"email":"c@d.com","phone":"8765432109"}]
        Path(jf).write_text(json.dumps(data), encoding="utf-8")
        r = process_json(jf, os.path.join(td,"mj.json"), os.path.join(td,"rj.json"), use_llm=False)
        assert r.total_pii_found >= 4
    _run_test("JSON array of records (non-dict root) processed correctly", _t_ec_json_list)


# ── SUMMARY ────────────────────────────────────────────────────
elapsed = time.time() - t0
total = len(_suite.passed) + len(_suite.failed) + len(_suite.errors)

print(f"\n{'═'*60}")
print(f"  Results: \033[32m{len(_suite.passed)} passed\033[0m  "
      f"\033[31m{len(_suite.failed)} failed\033[0m  "
      f"\033[33m{len(_suite.errors)} errors\033[0m  "
      f"({total} total)  [{elapsed:.2f}s]")
print(f"{'═'*60}\n")

if _suite.failed or _suite.errors:
    print("FAILED tests:")
    for name, msg in _suite.failed:
        print(f"  ✗ {name}: {msg}")
    for name, tb in _suite.errors:
        print(f"  ! {name}:\n{tb}")
    sys.exit(1)
else:
    print("\033[1;32m  All tests passed! ✓\033[0m\n")
    sys.exit(0)
