from app.main import app

# Run with:
# uvicorn app:app --reload
